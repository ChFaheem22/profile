import Link from 'next/link';
import Image from 'next/image';
import RoleCycle from './components/role-cycle';

const stack = ['React', 'Next.js', 'Flutter', 'Node.js', 'MongoDB', 'Python'];

const services = [
  {
    icon: '🖥️',
    title: 'Frontend Development',
    desc: 'Responsive, accessible interfaces built with React and Next.js, from Figma to production.',
  },
  {
    icon: '📱',
    title: 'Mobile Apps',
    desc: 'Cross-platform mobile apps with Flutter, backed by Firebase authentication and storage.',
  },
  {
    icon: '🔗',
    title: 'Full-Stack (MERN)',
    desc: 'End-to-end features across MongoDB, Express, React and Node — auth, bookings, dashboards.',
  },
  {
    icon: '🎨',
    title: 'UI Implementation',
    desc: 'Turning designs into pixel-accurate, reusable component systems with clean state management.',
  },
  {
    icon: '⚡',
    title: 'Performance',
    desc: 'Faster load times and smoother interactions through profiling and practical optimization.',
  },
  {
    icon: '🤝',
    title: 'Collaboration',
    desc: 'Git-based workflows, code reviews, and clear communication through the full project lifecycle.',
  },
];

const Home = () => {
  return (
    <main className="home-container">
      <div className="blob blob-1"></div>
      <div className="blob blob-2"></div>

      <section className="hero">
        <div className="hero-content">
          <span className="badge">● Available for freelance & internship work</span>
          <h1>
            Hi, I&apos;m <span className="gradText">Faheem</span>
          </h1>
          <RoleCycle />
          <p className="intro">
            I&apos;m a Software Engineering student focused on building fast,
            scalable, and user-centered applications. I specialize in{' '}
            <strong>React</strong> and <strong>Next.js</strong>, and extend
            that into mobile with <strong>Flutter</strong> — crafting clean
            UI with smooth, dependable user experiences.
          </p>

          <div className="buttons">
            <Link className="btn primary" href="/projects">
              View My Work
            </Link>
            <Link className="btn outline" href="/about">
              About Me
            </Link>
          </div>

          <div className="stats-row">
            <div className="stat">
              <div className="num">6+</div>
              <div className="label">Projects Shipped</div>
            </div>
            <div className="stat">
              <div className="num">1</div>
              <div className="label">Internship</div>
            </div>
            <div className="stat">
              <div className="num">3+</div>
              <div className="label">Stacks — Web, Mobile, AI</div>
            </div>
          </div>
        </div>

        <div className="hero-image-wrapper">
          <div className="image-container">
            <Image
              src="/pic-4.jpeg"
              alt="Faheem - Frontend Developer"
              className="profile-img"
              width={400}
              height={500}
              priority
            />
          </div>
          <div className="floating-card top">
            <span className="dot" />
            Open to work
          </div>
          <div className="floating-card bottom">📍 Lahore, Pakistan</div>
        </div>
      </section>

      <div className="stack-strip">
        <div className="container">
          <span className="label">core stack —</span>
          <div className="pills">
            {stack.map((s) => (
              <span className="pill" key={s}>
                {s}
              </span>
            ))}
          </div>
        </div>
      </div>

      <section className="section">
        <div className="section-head">
          <span className="eyebrow">what i do</span>
          <h2>Practical skills, applied to real problems</h2>
        </div>
        <div className="services-grid">
          {services.map((s) => (
            <div className="service-card" key={s.title}>
              <div className="icon">{s.icon}</div>
              <h3>{s.title}</h3>
              <p>{s.desc}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="contact-cta">
        <div className="cta-content">
          <h3>Let&apos;s build something amazing together.</h3>
          <p>Interested in collaborating or discussing a project opportunity?</p>
          <Link className="btn white-btn" href="/contact">
            Let&apos;s Connect
          </Link>
        </div>
      </section>
    </main>
  );
};

export default Home;
