import { FaGithub, FaLinkedin, FaInstagram } from 'react-icons/fa';

const links = [
  { id: 1, icon: <FaGithub />, href: 'https://github.com/ChFaheem22', label: 'GitHub' },
  { id: 2, icon: <FaLinkedin />, href: 'https://linkedin.com/in/faheemch22', label: 'LinkedIn' },
  {
    id: 3,
    icon: <FaInstagram />,
    href: 'https://www.instagram.com/___faheem._',
    label: 'Instagram',
  },
];

const Footer = () => {
  return (
    <footer className="footer">
      <div className="container">
        <span className="copy">© {new Date().getFullYear()} Faheem. Built with Next.js.</span>
        <div className="socials">
          {links.map((link) => (
            <a
              key={link.id}
              href={link.href}
              target="_blank"
              rel="noopener noreferrer"
              className="social-icon"
              aria-label={link.label}
            >
              {link.icon}
            </a>
          ))}
        </div>
      </div>
    </footer>
  );
};

export default Footer;
