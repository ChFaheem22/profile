import styles from './Projects.module.css';

const projects = [
  {
    name: 'quickserve',
    tagline: 'MERN service-booking platform',
    description:
      'A full-stack web application connecting users with local service providers. Includes authentication, service listings, real-time booking, role-based dashboards, payment method support, and a ratings & reviews system.',
    tools: ['MongoDB', 'Express.js', 'React.js', 'Node.js'],
    grad: 'linear-gradient(135deg, #7c5cfc, #22d3ee)',
    link: 'https://frontend-woad-beta-94.vercel.app/',
    linkLabel: 'Live demo ↗',
  },
  {
    name: 'drivego',
    tagline: 'Flutter car rental app',
    description:
      'A full-featured mobile car rental ecosystem built with Flutter. Offers real-time vehicle availability, seamless booking flows, and secure identity verification.',
    tools: ['Flutter', 'Dart', 'Firebase Auth', 'Cloudinary'],
    grad: 'linear-gradient(135deg, #06b6d4, #7c5cfc)',
    link: 'https://github.com/ChFaheem22/flutter.git',
    linkLabel: 'GitHub repository ↗',
  },
  {
    name: 'autosmart-ai',
    tagline: 'AI car recommendation & pricing',
    description:
      'A CustomTkinter desktop app that recommends cars and predicts fair market price using a model trained on a PakWheels used-car listings dataset covering Lahore, Karachi and Islamabad.',
    tools: ['Python', 'CustomTkinter', 'Machine Learning'],
    grad: 'linear-gradient(135deg, #f97316, #7c5cfc)',
    link: '#',
    linkLabel: 'Add repository link',
  },
  {
    name: 'carapp',
    tagline: 'AI-powered car pricing desktop app',
    description:
      'A Python/CustomTkinter desktop application with an AI-powered car pricing system, built after a thorough exploratory data analysis of a PakWheels used-car dataset.',
    tools: ['Python', 'CustomTkinter', 'Pandas'],
    grad: 'linear-gradient(135deg, #ef4444, #f97316)',
    link: '#',
    linkLabel: 'Add repository link',
  },
  {
    name: 'car-rental-system',
    tagline: 'Database-driven rental management',
    description:
      'A complete system to manage vehicle rentals, customer records, and booking operations. Designed the ERD and relational schema in MySQL, with a NoSQL alternative explored in MongoDB.',
    tools: ['MySQL', 'MongoDB'],
    grad: 'linear-gradient(135deg, #eab308, #22d3ee)',
    link: '#',
    linkLabel: 'Add repository link',
  },
  {
    name: 'blog-app',
    tagline: 'Next.js blog application',
    description:
      'A modern blog web application focused on clean design, responsive layouts, and optimized performance, with accessibility and smooth navigation in mind.',
    tools: ['HTML', 'CSS', 'React.js', 'Next.js'],
    grad: 'linear-gradient(135deg, #22d3ee, #7c5cfc)',
    link: 'https://blog-phi-blush-60.vercel.app/',
    linkLabel: 'Live demo ↗',
  },
];

const Project = () => {
  return (
    <div className={styles.wrap}>
      <div className={styles.container}>
        <span className="eyebrow">selected work</span>
        <h1 className={styles.heading}>Projects</h1>
        <p className={styles.sub}>
          A mix of web, mobile and AI-assisted tools — spanning MERN, Next.js, Flutter and Python.
        </p>

        <div className={styles.grid}>
          {projects.map((project) => (
            <div key={project.name} className={styles.card}>
              <div className={styles.cover} style={{ background: project.grad }}>
                <span className={styles.coverName}>{project.name}</span>
              </div>
              <div className={styles.body}>
                <p className={styles.tagline}>{project.tagline}</p>
                <p className={styles.desc}>{project.description}</p>
                <div className={styles.tags}>
                  {project.tools.map((tool) => (
                    <span className={styles.tag} key={tool}>
                      {tool}
                    </span>
                  ))}
                </div>
                <a
                  href={project.link}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={styles.link}
                >
                  {project.linkLabel}
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Project;
