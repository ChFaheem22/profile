'use client';
import { useEffect, useState } from 'react';

const ROLES = ['Frontend Developer', 'MERN Stack Enthusiast', 'Flutter Developer'];

const RoleCycle = () => {
  const [index, setIndex] = useState(0);

  useEffect(() => {
    const id = setInterval(() => {
      setIndex((i) => (i + 1) % ROLES.length);
    }, 2400);
    return () => clearInterval(id);
  }, []);

  return (
    <h2 className="role-cycle">
      <span className="word">{ROLES[index]}</span>
      <span className="caret" />
    </h2>
  );
};

export default RoleCycle;
